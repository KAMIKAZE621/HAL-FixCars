fx_version 'cerulean'
game 'gta5'

author 'HAL Custom Script'
description 'QBCore Repair Station - Cash or Bank Payment'
version '1.4.0'

shared_script '@ox_lib/init.lua'
shared_script 'config.lua'

client_script 'client.lua'
server_script 'server.lua'
